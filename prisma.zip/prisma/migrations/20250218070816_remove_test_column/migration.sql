/*
  Warnings:

  - You are about to drop the column `test` on the `Parent` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Parent" DROP COLUMN "test";
