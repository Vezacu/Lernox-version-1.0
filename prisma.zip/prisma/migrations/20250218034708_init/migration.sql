-- AlterTable
ALTER TABLE "Parent" ADD COLUMN     "img" TEXT;
