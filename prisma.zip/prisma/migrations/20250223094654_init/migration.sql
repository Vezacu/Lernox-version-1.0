-- AlterTable
ALTER TABLE "AdmissionForm" ADD COLUMN     "img" TEXT;

-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "img" TEXT;
