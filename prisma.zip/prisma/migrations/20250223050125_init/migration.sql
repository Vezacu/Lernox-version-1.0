-- AlterEnum
ALTER TYPE "UserSex" ADD VALUE 'OTHER';
