"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Dispatch, SetStateAction } from "react";
import { useForm } from "react-hook-form";
import { useFormState } from "react-dom";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import InputField from "../InputField";
import { attendanceSchema } from "@/lib/formValidationSchemas";
import { createAttendance, updateAttendance } from "@/lib/actions";

const AttendanceForm = ({ type, data, setOpen, relatedData }: {
  type: "create" | "update";
  data?: any;
  setOpen: Dispatch<SetStateAction<boolean>>;
  relatedData?: any;
}) => {
  const router = useRouter();
  const { register, handleSubmit, formState: { errors }, watch } = useForm({
    resolver: zodResolver(attendanceSchema),
    defaultValues: data
  });

  const [state, formAction] = useFormState(
    type === "create" ? createAttendance : updateAttendance,
    { success: false, error: false }
  );

  const onSubmit = handleSubmit((formData) => {
    const submissionData = {
      ...formData,
      date: new Date(formData.date),
      studentId: formData.studentId,
      lessonId: Number(formData.lessonId),
      present: formData.present === "true"
    };
    formAction(submissionData);
  });

  useEffect(() => {
    if (state.success) {
      toast.success(`Attendance ${type === 'create' ? 'created' : 'updated'}`);
      setOpen(false);
      router.refresh();
    } else if (state.error) {
      toast.error("Error saving attendance");
    }
  }, [state]);

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4 p-4">
      <h2 className="text-xl font-semibold">
        {type === 'create' ? 'New Attendance' : 'Edit Attendance'}
      </h2>

      <InputField
        label="Date"
        name="date"
        type="date"
        register={register}
      />

      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <label>Student</label>
          <select {...register("studentId")} className="input">
            {relatedData.students.map((student: any) => (
              <option key={student.id} value={student.id}>
                {student.name} {student.surname}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-2">
          <label>Lesson</label>
          <select {...register("lessonId")} className="input">
            {relatedData.lessons.map((lesson: any) => (
              <option key={lesson.id} value={lesson.id}>
                {new Date(lesson.startTime).toLocaleTimeString()} - 
                {lesson.subjectOffering.subject.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <label>Attendance Status</label>
        <select {...register("present")} className="input">
          <option value="true">Present</option>
          <option value="false">Absent</option>
        </select>
      </div>

      <button type="submit" className="btn-primary">
        {type === 'create' ? 'Create' : 'Update'}
      </button>
    </form>
  );
};

export default AttendanceForm;