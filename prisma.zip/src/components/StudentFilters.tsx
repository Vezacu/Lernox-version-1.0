"use client";
import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from "next/navigation";
import { ChangeEvent } from "react";

interface Course {
  id: number;
  name: string;
}
interface Semester {
  id: number;
  number: number;
  courseId: number; // Make sure courseId is included
}
interface StudentFiltersProps {
  courses: Course[];
  semesters: Semester[];
}

const StudentFilters = ({ courses, semesters }: StudentFiltersProps) => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [filteredSemesters, setFilteredSemesters] = useState<Semester[]>([]);
  
  // Get current values from URL
  const currentCourseId = searchParams.get("courseId") || "";
  const currentSemesterId = searchParams.get("semesterId") || "";

  // Update filtered semesters when course changes
  useEffect(() => {
    if (currentCourseId) {
      // Filter semesters based on selected course
      const courseSemesters = semesters.filter(
        sem => sem.courseId === parseInt(currentCourseId)
      );
      setFilteredSemesters(courseSemesters);
      
      // If current semester is not part of this course, clear it
      const isSemesterValid = courseSemesters.some(
        sem => sem.id.toString() === currentSemesterId
      );
      
      if (currentSemesterId && !isSemesterValid) {
        const params = new URLSearchParams(searchParams.toString());
        params.delete("semesterId");
        router.push(`?${params.toString()}`);
      }
    } else {
      // If no course selected, show all semesters
      setFilteredSemesters(semesters);
    }
  }, [currentCourseId, semesters, currentSemesterId]);

  // Handle course filter change
  const handleCourseChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const courseId = e.target.value;
    const params = new URLSearchParams(searchParams.toString());

    if (courseId) {
      params.set("courseId", courseId);
    } else {
      params.delete("courseId");
    }
    
    // Clear semester selection when course changes
    params.delete("semesterId");
    
    router.push(`?${params.toString()}`);
  };

  // Handle semester filter change
  const handleSemesterChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const semesterId = e.target.value;
    const params = new URLSearchParams(searchParams.toString());

    if (semesterId) {
      params.set("semesterId", semesterId);
    } else {
      params.delete("semesterId");
    }
    
    router.push(`?${params.toString()}`);
  };

  // Handle sort filter change
  const handleSortChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const sort = e.target.value;
    const params = new URLSearchParams(searchParams.toString());

    if (sort) {
      params.set("sort", sort);
    } else {
      params.delete("sort");
    }
    
    router.push(`?${params.toString()}`);
  };

  return (
    <div className="flex items-center gap-4">
      {/* Course Filter Dropdown */}
      <select
        onChange={handleCourseChange}
        defaultValue={currentCourseId}
        className="p-2 border border-gray-300 rounded-md"
      >
        <option value="">All Courses</option>
        {courses.map((course) => (
          <option value={course.id.toString()} key={course.id}>
            {course.name}
          </option>
        ))}
      </select>

      {/* Semester Filter Dropdown */}
      <select
        onChange={handleSemesterChange}
        value={currentSemesterId}
        className="p-2 border border-gray-300 rounded-md"
      >
        <option value="">All Semesters</option>
        {filteredSemesters.map((semester) => (
          <option value={semester.id.toString()} key={semester.id}>
            Semester {semester.number}
          </option>
        ))}
      </select>

      {/* Sort Dropdown */}
      <select
        onChange={handleSortChange}
        defaultValue={searchParams.get("sort") || ""}
        className="p-2 border border-gray-300 rounded-md"
      >
        <option value="">Sort By</option>
        <option value="asc">A to Z</option>
        <option value="desc">Z to A</option>
      </select>
    </div>
  );
};

export default StudentFilters;
