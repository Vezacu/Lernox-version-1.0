"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function AttendanceFilters({ courses, semesters }: {
  courses: any[];
  semesters: any[];
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [selectedCourse, setSelectedCourse] = useState("");
  const [selectedSemester, setSelectedSemester] = useState("");

  const handleFilter = (name: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(name, value);
    else params.delete(name);
    router.push(`?${params.toString()}`);
  };

  return (
    <div className="flex gap-4">
      <select
        value={selectedCourse}
        onChange={(e) => {
          setSelectedCourse(e.target.value);
          handleFilter('courseId', e.target.value);
        }}
        className="input"
      >
        <option value="">All Courses</option>
        {courses.map(course => (
          <option key={course.id} value={course.id}>{course.name}</option>
        ))}
      </select>

      <select
        value={selectedSemester}
        onChange={(e) => {
          setSelectedSemester(e.target.value);
          handleFilter('semesterId', e.target.value);
        }}
        className="input"
      >
        <option value="">All Semesters</option>
        {semesters.map(semester => (
          <option key={semester.id} value={semester.id}>
            Sem {semester.number}
          </option>
        ))}
      </select>

      <input
        type="date"
        onChange={(e) => handleFilter('date', e.target.value)}
        className="input"
      />
    </div>
  );
}