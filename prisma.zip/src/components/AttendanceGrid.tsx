"use client";

import { useEffect, useState } from 'react';
import { saveBulkAttendance } from '@/lib/actions';
import { Lesson, Student, Attendance } from '@prisma/client';

interface AttendanceGridProps {
  lessons: Lesson[];
  students: Student[];
  initialAttendances: Attendance[];
}

const AttendanceGrid = ({ lessons, students, initialAttendances }: AttendanceGridProps) => {
  const [selectedLesson, setSelectedLesson] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [attendanceMap, setAttendanceMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const initState: Record<string, boolean> = {};
    students.forEach(student => {
      const existing = initialAttendances.find(a => 
        a.studentId === student.id && 
        new Date(a.date).toDateString() === selectedDate.toDateString()
      );
      initState[student.id] = existing?.present || false;
    });
    setAttendanceMap(initState);
  }, [selectedDate, students, initialAttendances]);

  const handleCheckboxChange = (studentId: string) => {
    setAttendanceMap(prev => ({
      ...prev,
      [studentId]: !prev[studentId]
    }));
  };

  const handleSubmit = async () => {
    const attendances = Object.entries(attendanceMap).map(([studentId, present]) => ({
      studentId,
      lessonId: selectedLesson,
      date: selectedDate,
      present
    }));

    await saveBulkAttendance(attendances);
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <div className="flex gap-4 mb-6">
        <select 
          className="p-2 border rounded"
          value={selectedLesson}
          onChange={(e) => setSelectedLesson(e.target.value)}
        >
          <option value="">Select Lesson</option>
          {lessons.map(lesson => (
            <option key={lesson.id} value={lesson.id}>
              {new Date(lesson.startTime).toLocaleTimeString()} - {(lesson as any).subjectOffering?.subject.name}
            </option>
          ))}
        </select>
        
        <input
          type="date"
          value={selectedDate.toISOString().split('T')[0]}
          onChange={(e) => setSelectedDate(new Date(e.target.value))}
          className="p-2 border rounded"
        />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="p-2 border bg-gray-50">Student</th>
              {Array.from({ length: 20 }).map((_, index) => (
                <th key={index} className="p-2 border bg-gray-50 w-12">
                  {index + 1}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {students.map(student => (
              <tr key={student.id} className="hover:bg-gray-50">
                <td className="p-2 border">
                  {student.name} {student.surname}
                </td>
                {Array.from({ length: 20 }).map((_, index) => (
                  <td key={index} className="p-2 border text-center">
                    <input
                      type="checkbox"
                      checked={attendanceMap[student.id] || false}
                      onChange={() => handleCheckboxChange(student.id)}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex justify-end">
        <button
          onClick={handleSubmit}
          disabled={!selectedLesson}
          className="px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-300"
        >
          Save Attendance
        </button>
      </div>
    </div>
  );
};

export default AttendanceGrid;