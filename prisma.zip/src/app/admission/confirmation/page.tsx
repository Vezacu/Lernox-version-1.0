// "use client";

// import Link from "next/link";
// import { useSearchParams } from "next/navigation";

// export default function ConfirmationPage() {
//   const searchParams = useSearchParams();
//   const id = searchParams.get("id");

//   return (
//     <div className="container mx-auto px-4 py-16">
//       <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow text-center">
//         <div className="mb-6">
//           <svg
//             className="w-16 h-16 text-green-500 mx-auto"
//             fill="none"
//             stroke="currentColor"
//             viewBox="0 0 24 24"
//             xmlns="http://www.w3.org/2000/svg"
//           >
//             <path
//               strokeLinecap="round"
//               strokeLinejoin="round"
//               strokeWidth="2"
//               d="M5 13l4 4L19 7"
//             ></path>
//           </svg>
//         </div>
        
//         <h1 className="text-2xl font-bold mb-4">Application Submitted Successfully!</h1>
        
//         <p className="text-gray-600 mb-6">
//           Thank you for submitting your admission application. Your application has been received and is being processed.
//         </p>
        
//         {id && (
//           <div className="bg-gray-100 p-4 rounded mb-6">
//             <p className="text-gray-700">Your application reference number:</p>
//             <p className="font-bold text-lg">{id}</p>
//           </div>
//         )}
        
//         <div className="mb-6">
//           <h2 className="text-lg font-semibold mb-2">Next Steps:</h2>
//           <ol className="text-left text-gray-600 list-decimal pl-6">
//             <li className="mb-2">We will review your application within 3-5 business days.</li>
//             <li className="mb-2">You will receive an email with payment instructions.</li>
//             <li className="mb-2">Once payment is verified, we will send you a confirmation of enrollment.</li>
//           </ol>
//         </div>
        
//         <div className="flex justify-center gap-4">
//           <Link href="/" className="bg-blue-400 text-white px-6 py-2 rounded-md hover:bg-blue-500 transition-colors">
//             Return to Home
//           </Link>
//           <Link href="/admission/status" className="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition-colors">
//             Check Application Status
//           </Link>
//         </div>
//       </div>
//     </div>
//   );
// }

"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect } from "react";

export default function ConfirmationPage() {
  const searchParams = useSearchParams();
  const id = searchParams.get("id");

  // Prevent back navigation to the form
  useEffect(() => {
    // Replace current history entry to prevent going back to the form
    window.history.replaceState(null, '', '/admission/confirmation');
  }, []);

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow text-center">
        <div className="mb-6">
          <svg
            className="w-16 h-16 text-green-500 mx-auto"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            ></path>
          </svg>
        </div>
        
        <h1 className="text-2xl font-bold mb-4">Application Submitted Successfully!</h1>
        
        <p className="text-gray-600 mb-6">
          Thank you for submitting your admission application. Your application has been received and is being processed.
        </p>
        
        {id && (
          <div className="bg-gray-100 p-4 rounded mb-6">
            <p className="text-gray-700">Your application reference number:</p>
            <p className="font-bold text-lg">{id}</p>
          </div>
        )}
        
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Next Steps:</h2>
          <ol className="text-left text-gray-600 list-decimal pl-6">
            <li className="mb-2">We will review your application within 3-5 business days.</li>
            <li className="mb-2">A verification email has been sent to the parent's email address. Please check and verify.</li>
            <li className="mb-2">Once both payment and parent email are verified, we will send login credentials.</li>
            <li className="mb-2">Student and parent accounts will be automatically created when the process is complete.</li>
          </ol>
        </div>
        
        <div className="flex justify-center gap-4">
          <Link href="/" className="bg-blue-400 text-white px-6 py-2 rounded-md hover:bg-blue-500 transition-colors">
            Return to Home
          </Link>
          <Link href="/admission/status" className="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition-colors">
            Check Application Status
          </Link>
        </div>
      </div>
    </div>
  );
}