import React from 'react';
import './aboutpage.css'; 
import Image from 'next/image';
import '../homepage/Landingpage.css';
const AboutPage = () => {
  return (
    <div className="container">
      {/* Top Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <a href="/">HOME</a>
        </div>
      </nav>

      {/* About Section */}
      <section className="about-section">
        <div className="about-content">
          <h1 className="about-title">About Us</h1>
          <p className="about-description">
            Welcome to the future of innovation. We are a team of passionate individuals dedicated to pushing the boundaries of technology and design. Our mission is to create solutions that not only solve problems but also inspire and transform the way we interact with the world.
          </p>
          <div className="about-features">
            <div className="feature-card">
              <h2>Innovation</h2>
              <p>We thrive on creativity and cutting-edge technology to deliver groundbreaking solutions.</p>
            </div>
            <div className="feature-card">
              <h2>Collaboration</h2>
              <p>Our team works together seamlessly, combining diverse skills to achieve extraordinary results.</p>
            </div>
            <div className="feature-card">
              <h2>Sustainability</h2>
              <p>We are committed to building a sustainable future through eco-friendly practices and technologies.</p>
            </div>
          </div>
        </div>
      </section>
      {/* Bottom Navbar */}
            <nav className="bottom-navbar">
              <div className="icon-container">
                <a href="https://wa.me/your-whatsapp-link" target="_blank" rel="noopener noreferrer">
                  <Image src="/whatsapp.png" alt="WhatsApp" width={24} height={24} />
                </a>
                <a href="https://instagram.com/your-instagram-link" target="_blank" rel="noopener noreferrer">
                  <Image src="/instagram.png" alt="Instagram" width={24} height={24} />
                </a>
                <a href="https://twitter.com/your-twitter-link" target="_blank" rel="noopener noreferrer">
                  <Image src="/twitter.png" alt="Twitter" width={24} height={24} />
                </a>
              </div>
              <div className="our-links">
                <h3>Our Links</h3>
                <a href="/courses">Courses</a>
                <a href="/blog">Blog</a>
                <a href="/contact">Contact</a>
              </div>
              <div className="address-contact">
                <h3>Address and Contact</h3>
                <p>123 College Street, City</p>
                <p>Email: info@lernox.com</p>
                <p>Phone: +123 456 7890</p>
              </div>
            </nav>
    </div>
  );
};

export default AboutPage;