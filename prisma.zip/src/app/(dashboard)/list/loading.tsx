const Loading = () => {
    return  (
        <div className='w-full h-full flex item-center justify-center'>
            loading...
        </div>
    ) 
    
}

export default Loading