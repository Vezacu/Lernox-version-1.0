import AttendanceGrid from '@/components/AttendanceGrid';
import prisma from '@/lib/prisma';

export default async function AttendancePage() {
  const [lessons, students, attendances] = await Promise.all([
    prisma.lesson.findMany({
      include: {
        subjectOffering: {
          include: {
            subject: true,
            semester: true
          }
        }
      }
    }),
    prisma.student.findMany({
      include: {
        enrollments: {
          include: {
            subjectOffering: true
          }
        }
      }
    }),
    prisma.attendance.findMany()
  ]);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Attendance Management</h1>
      <AttendanceGrid 
        lessons={lessons}
        students={students}
        initialAttendances={attendances}
      />
    </div>
  );
}