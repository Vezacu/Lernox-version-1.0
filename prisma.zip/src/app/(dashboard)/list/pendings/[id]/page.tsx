import prisma from "@/lib/prisma";
import Image from "next/image";

const ViewPaymentPage = async ({ params }: { params: { id: string } }) => {
  const payment = await prisma.payment.findUnique({
    where: { id: params.id },
    include: {
      admission: true,
    },
  });

  if (!payment) {
    return <div>Payment not found</div>;
  }

  return (
    <div className="bg-white p-6 rounded-md shadow-md">
      <h1 className="text-2xl font-bold mb-6">Student Details</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Student Information */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Student Information</h2>
          <div className="space-y-4">
          <p><strong>Name:</strong> {payment.admission.studentName}</p>
          <p><strong>Surname:</strong> {payment.admission.studentSurname}</p>
          <p><strong>Email:</strong> {payment.admission.email}</p>
          <p><strong>Phone:</strong> {payment.admission.phone}</p>
          <p><strong>Address:</strong> {payment.admission.address}</p>
          <p><strong>Birthday:</strong> {payment.admission.birthday.toLocaleDateString()}</p>
          <p><strong>Blood Type:</strong> {payment.admission.bloodType}</p>
          <p><strong>Sex:</strong> {payment.admission.sex}</p>
       </div>
        </div>

        {/* Payment Information */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Payment Information</h2>
          <div className="space-y-4">
            <p><strong>Amount:</strong> ₹{payment.amount}</p>
            <p><strong>Status:</strong> {payment.status}</p>
            {payment.img && (
              <div>
                <p><strong>Payment Screenshot:</strong></p>
                <Image
                  src={payment.img}
                  alt="Payment Screenshot"
                  width={300}
                  height={200}
                  className="rounded-lg"
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewPaymentPage;