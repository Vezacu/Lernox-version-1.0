// import FormContainer from "@/components/FormContainer";
// import Pagination from "@/components/Pagination";
// import Table from "@/components/Table";
// import TableSearch from "@/components/TableSearch";
// import VerifyPaymentButton from "@/components/VerifyPaymentButton";
// import prisma from "@/lib/prisma";
// import { ITEM_PER_PAGE } from "@/lib/settings";
// import { PaymentStatus } from "@prisma/client";
// import Image from "next/image";
// import Link from "next/link";

// const PendingPaymentsPage = async ({ searchParams }: { searchParams: { [key: string]: string | undefined } }) => {
//   const { page, sort, status } = searchParams;
//   const p = page ? parseInt(page) : 1;

//   // Filter conditions
//   const statusFilter = status === "verified" ? PaymentStatus.APPROVED : PaymentStatus.PENDING;

//   const query: any = {
//     status: statusFilter,
//   };

//   const orderBy: any = {};
//   if (sort === "asc" || sort === "desc") {
//     orderBy.studentName = sort;
//   }

//   const data = await prisma.payment.findMany({
//     where: query,
//     include: {
//       admission: true,
//     },
//     take: ITEM_PER_PAGE,
//     skip: ITEM_PER_PAGE * (p - 1),
//     orderBy,
//   });

//   const handleVerify = async (paymentId: string) => {
//     "use server"; // Enables Server Action

//     await prisma.payment.update({
//       where: { id: paymentId },
//       data: { status: PaymentStatus.APPROVED },
//     });
//   };

//   const columns = [
//     { header: "Student Name", accessor: "name" },
//     { header: "Surname", accessor: "surname" },
//     { header: "Status", accessor: "status" },
//     { header: "Payment Screenshot", accessor: "image" },
//     { header: "Actions", accessor: "actions" },
//   ];

//   const renderRow = (item: any) => (
//     <tr key={item.id} className="border-b border-gray-200 even:bg-gray-50 text-sm">
//       {/* Changed admissionForm to admission */}
//       <td className="p-4">{item.admission.studentName}</td>
//       <td className="p-4">{item.admission.studentSurname}</td>
//       <td className="p-4 font-semibold text-red-500">{item.status}</td>
//       <td className="p-4">
//         {item.img ? (
//           <Image src={item.img} alt="Payment Screenshot" width={100} height={100} />
//         ) : (
//           <span>No Image</span>
//         )}
//       </td>
//       <td className="p-4 flex gap-2">
//         {item.status === PaymentStatus.PENDING && (
//           <VerifyPaymentButton paymentId={item.id} onVerify={() => handleVerify(item.id)} />
//         )}
//         <Link href={`/list/pendings/${item.id}`}>
//           <button className="px-4 py-2 bg-blue-500 text-white rounded">View</button>
//         </Link>
//       </td>
//     </tr>
//   );

//   return (
//     <div className="bg-white p-4 rounded-md flex-1 m-4 mt-0">
//       <h1 className="text-lg font-semibold">Pending Payments</h1>
//       <div className="flex items-center justify-between">
//         <TableSearch />
//         <div className="flex gap-2">
//           <Link href="?status=pending">
//             <button className="px-4 py-2 bg-yellow-500 text-white rounded">Pending</button>
//           </Link>
//           <Link href="?status=verified">
//             <button className="px-4 py-2 bg-blue-500 text-white rounded">Verified</button>
//           </Link>
//         </div>
//       </div>
//       <Table columns={columns} renderRow={renderRow} data={data || []} />
//     </div>
//   );
// };

// export default PendingPaymentsPage;

import FormContainer from "@/components/FormContainer";
import Pagination from "@/components/Pagination";
import Table from "@/components/Table";
import TableSearch from "@/components/TableSearch";
import VerifyPaymentButton from "@/components/VerifyPaymentButton";
import prisma from "@/lib/prisma";
import { ITEM_PER_PAGE } from "@/lib/settings";
import { PaymentStatus } from "@prisma/client";
import Image from "next/image";
import Link from "next/link";

const PendingPaymentsPage = async ({ searchParams }: { searchParams: { [key: string]: string | undefined } }) => {
  const { page, sort, status } = searchParams;
  const p = page ? parseInt(page) : 1;

  // Filter conditions
  const statusFilter = status === "verified" ? PaymentStatus.APPROVED : PaymentStatus.PENDING;

  const query: any = {
    status: statusFilter,
  };

  const orderBy: any = {};
  if (sort === "asc" || sort === "desc") {
    orderBy.studentName = sort;
  }

  const data = await prisma.payment.findMany({
    where: query,
    include: {
      admission: true,
    },
    take: ITEM_PER_PAGE,
    skip: ITEM_PER_PAGE * (p - 1),
    orderBy,
  });

  const totalPayments = await prisma.payment.count({
    where: query,
  });

  const columns = [
    { header: "Student Name", accessor: "name" },
    { header: "Surname", accessor: "surname" },
    { header: "Status", accessor: "status" },
    { header: "Payment Screenshot", accessor: "image" },
    { header: "Actions", accessor: "actions" },
  ];

  const renderRow = (item: any) => (
    <tr key={item.id} className="border-b border-gray-200 even:bg-gray-50 text-sm">
      <td className="p-4">{item.admission.studentName}</td>
      <td className="p-4">{item.admission.studentSurname}</td>
      <td className="p-4 font-semibold text-red-500">{item.status}</td>
      <td className="p-4">
        {item.img ? (
          <Image src={item.img} alt="Payment Screenshot" width={100} height={100} />
        ) : (
          <span>No Image</span>
        )}
      </td>
      <td className="p-4 flex gap-2">
        {item.status === PaymentStatus.PENDING && (
          <VerifyPaymentButton paymentId={item.id} />
        )}
        <Link href={`/list/pendings/${item.id}`}>
          <button className="px-4 py-2 bg-blue-500 text-white rounded">View</button>
        </Link>
      </td>
    </tr>
  );

  const totalPages = Math.ceil(totalPayments / ITEM_PER_PAGE);

  return (
    <div className="bg-white p-4 rounded-md flex-1 m-4 mt-0">
      <h1 className="text-lg font-semibold">Pending Payments</h1>
      <div className="flex items-center justify-between">
        <TableSearch />
        <div className="flex gap-2">
          <Link href="?status=pending">
            <button className="px-4 py-2 bg-yellow-500 text-white rounded">Pending</button>
          </Link>
          <Link href="?status=verified">
            <button className="px-4 py-2 bg-blue-500 text-white rounded">Verified</button>
          </Link>
        </div>
      </div>
      <Table columns={columns} renderRow={renderRow} data={data || []} />
      {totalPages > 1 && (
        <Pagination page={p} count={totalPages} />
      )}
    </div>
  );
};

export default PendingPaymentsPage;