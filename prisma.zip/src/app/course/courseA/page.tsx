import React from "react"
const Page = () => {
  return (
    <div className=''>courseA Page</div>
  )
}

export default Page  