"use client"
import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import './course.css';  // Importing CSS file
import '../homepage/Landingpage.css';


export default function Courses() {
  const router = useRouter();
  const [selectedCourse, setSelectedCourse] = useState("");

  const courses = [
    { name: "BCA", desc: "A three-year degree program focusing on computer applications.", image: "/one.jpg" },
    { name: "MCA", desc: "A three-year postgraduate program in advanced computer applications.", image: "/two.jpg" },
    { name: "B.Tech", desc: "A four-year engineering program combining theory with practical experience.", image: "/three.jpg" },
    { name: "M.Tech", desc: "A professional postgraduate degree preparing students for advanced engineering roles.", image: "/four.jpg" }
  ];

  const handleCourseSelect = (course:string) => {
    setSelectedCourse(course);
    router.push(`/admission?course=${course}`);
  };

  return (
    <div className="container">
      <nav className="navbar">
        <div className="nav-left">
          <a href="/" className="text-blue-500 font-semibold hover:underline">Home</a>
          <a href="/courses" className="text-blue-500 font-semibold hover:underline">Courses</a>
        </div>
      </nav>

      <div className="hero-section">
        <Image src="/campus.jpg" alt="Campus" className="campus-image" width={1200} height={400} />
        <div className="hero-overlay">
          <h1 className="text-3xl font-bold">Our Courses</h1>
          <p className="text-lg">Explore cutting-edge programs tailored for your future.</p>
        </div>
      </div>

      <div className="course-grid">
        {courses.map((course) => (
          <div key={course.name} className="course-card">
            <Image src={course.image} alt={course.name} width={300} height={200} className="course-image" />
            <div className="course-content">
              <h2 className="text-xl font-bold">{course.name}</h2>
              <p className="text-gray-600 mb-4">{course.desc}</p>
              <button
                className="apply-button"
                onClick={() => handleCourseSelect(course.name)}
              >
                Apply Now
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
