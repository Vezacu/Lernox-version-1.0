"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { useUser } from "@clerk/nextjs";
import { useRouter } from "next/navigation";
import * as Clerk from "@clerk/elements/common";
import * as SignIn from "@clerk/elements/sign-in";

const HomePage = () => {
  const { isLoaded, isSignedIn, user } = useUser();
  const router = useRouter();
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    if (isLoaded) {
      if (isSignedIn) {
        const role = user?.publicMetadata?.role;
        router.replace(`/${role || "dashboard"}`);
      } else {
        setCheckingAuth(false);
      }
    }
  }, [isLoaded, isSignedIn, user, router]);

  if (checkingAuth) {
    return <div className="h-screen flex justify-center items-center bg-gray-900 text-white">...</div>;
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      {/* Top Navbar */}
      <nav className="flex justify-between items-center p-4 bg-white shadow-md">
        <div className="flex items-center gap-4">
          {/* Dropdown Toggle Button */}
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="p-2 bg-gray-200 rounded-md"
          >
            <Image src="/bar.png" alt="Menu" width={24} height={24} />
          </button>
          {/* Dropdown Menu */}
          {isDropdownOpen && (
            <div className="absolute top-12 left-4 bg-white shadow-lg rounded-md py-2 w-40">
              <Link href="#" className="block px-4 py-2 hover:bg-gray-200">HOME</Link>
              <Link href="/about" className="block px-4 py-2 hover:bg-gray-200">ABOUT</Link>
              <Link href="/course" className="block px-4 py-2 hover:bg-gray-200">COURSE</Link>
            </div>
          )}
          <div className="flex items-center gap-2">
            <Image src="/foxlogo.png" alt="LERNOX Logo" width={40} height={40} />
            <span className="text-lg font-bold">LERNOX</span>
          </div>
        </div>
        <button onClick={() => setShowLogin(true)} className="text-green-600 font-semibold">LOGIN</button>
      </nav>

      {showLogin ? (
        <div className="h-screen flex justify-center items-center bg-gray-900 text-white p-6">
          <div className="bg-gray-800 p-8 rounded-xl shadow-lg w-full max-w-md">
            <h1 className="text-2xl font-bold flex items-center gap-2 text-green-400 mb-4">
              <Image src="/logo.png" alt="LERNOX" width={30} height={30} />
              LΣRNϴX
            </h1>
            <h2 className="text-gray-400 mb-4">Sign in to your account</h2>
            <SignIn.Root>
              <SignIn.Step name="start" className="flex flex-col gap-4">
                <Clerk.GlobalError />
                <Clerk.Field name="identifier" className="flex flex-col gap-1">
                  <Clerk.Label className="text-sm text-gray-300">Username</Clerk.Label>
                  <Clerk.Input className="border border-gray-600 p-2 rounded-md bg-gray-700 text-white" type="text" />
                  <Clerk.FieldError className="text-sm text-red-400" />
                </Clerk.Field>
                <Clerk.Field name="password" className="flex flex-col gap-1">
                  <Clerk.Label className="text-sm text-gray-300">Password</Clerk.Label>
                  <Clerk.Input className="border border-gray-600 p-2 rounded-md bg-gray-700 text-white" type="password" />
                  <Clerk.FieldError className="text-sm text-red-400" />
                </Clerk.Field>
                <SignIn.Action submit className="mt-4 bg-green-500 hover:bg-green-600 transition-all text-white font-semibold py-2 rounded-md">
                  Sign In
                </SignIn.Action>
              </SignIn.Step>
            </SignIn.Root>
            <button onClick={() => setShowLogin(false)} className="mt-4 text-green-400 hover:text-green-300 underline">
              Back to Home
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Hero Section */}
          <div className="flex flex-col items-center text-center px-6 py-12 bg-green-100">
            <h1 className="text-4xl font-bold text-green-600">LERNOX</h1>
            <p className="mt-4 max-w-xl text-gray-700">
              Welcome to LERNOX, where innovation meets education. Our platform offers cutting-edge courses designed to help you achieve your goals and transform your future. Join us today and take the first step towards success!
            </p>
            <Link href="/course" className="mt-6 px-6 py-3 bg-green-500 text-white rounded-full font-semibold shadow-md hover:bg-green-600">JOIN US NOW</Link>
          </div>

          {/* Features Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 p-8">
            {["one.jpg", "two.jpg", "three.jpg", "four.jpg"].map((img, index) => (
              <div key={index} className="bg-white p-4 rounded-md shadow-lg">
                <Image src={`/${img}`} alt={`Feature ${index + 1}`} width={200} height={200} className="rounded-md" />
                <p className="mt-4 text-gray-700">
                  {index === 0 && "Discover a place where knowledge meets opportunity. We empower students with a world-class education and vibrant campus life."}
                  {index === 1 && "Our rigorous academic programs are designed to challenge and inspire. We prepare students for success in their careers and beyond."}
                  {index === 2 && "Join a diverse and dynamic student community. Participate in clubs, events, and make lifelong connections."}
                  {index === 3 && "We prepare you for success beyond the classroom with strong career support, internships, and a global alumni network."}
                </p>
              </div>
            ))}
          </div>

          {/* Dark Section */}
          <div className="bg-gray-900 text-white py-12 text-center">
            <p className="text-lg">Join us in shaping the future of education. Learn more about our mission and vision.</p>
            <Link href="/about" className="mt-4 inline-block px-6 py-3 bg-green-500 rounded-full font-semibold shadow-md hover:bg-green-600">Learn More About Us</Link>
          </div>

          {/* Footer */}
          <footer className="bg-gray-100 p-8 flex flex-col md:flex-row justify-between items-center text-gray-700">
            <div className="flex gap-4">
              <Link href="#"><Image src="/whatsapp.png" alt="WhatsApp" width={24} height={24} /></Link>
              <Link href="#"><Image src="/instagram.png" alt="Instagram" width={24} height={24} /></Link>
              <Link href="#"><Image src="/twitter.png" alt="Twitter" width={24} height={24} /></Link>
            </div>
            <div>
              <h3 className="font-semibold">Our Links</h3>
              <Link href="/courses" className="block">Courses</Link>
              <Link href="/blog" className="block">Blog</Link>
              <Link href="/contact" className="block">Contact</Link>
            </div>
            <div>
              <h3 className="font-semibold">Address and Contact</h3>
              <p>123 College Street, City</p>
              <p>Email: info@lernox.com</p>
              <p>Phone: +123 456 7890</p>
            </div>
          </footer>
        </>
      )}
    </div>
  );
};

export default HomePage;