import { UserSex } from "@prisma/client";
import { z } from "zod";

//Rules For Subjects
export const subjectSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(1, "Subject name is required"),
});

export type SubjectSchema = z.infer<typeof subjectSchema>;

//Rules For Classes
export const classSchema = z.object({
  id: z.coerce.number().optional(),
  name: z.string().min(1, { message: "Subject name is required!" }),
  capacity: z.coerce.number().min(1, { message: "Capacity name is required!" }),
  gradeId: z.coerce.number().min(1, { message: "Grade name is required!" }),
  supervisorId: z.coerce.string().optional(),
});
export type ClassSchema = z.infer<typeof classSchema>;

//Rules For Teachers
export const teacherSchema = z.object({
  id: z.string().optional(),
  username: z
    .string()
    .min(3, { message: "Username must be at least 3 characters long!" })
    .max(20, { message: "Username must be at most 20 characters long!" }),
  password: z
    .string()
    .min(8, { message: "Password must be at least 8 characters long!" })
    .optional()
    .or(z.literal("")),
  name: z.string().min(1, { message: "First name is required!" }),
  surname: z.string().min(1, { message: "Last name is required!" }),
  email: z
    .string()
    .email({ message: "Invalid email address!" })
    .optional()
    .or(z.literal("")),
  phone: z.string().optional(),
  address: z.string(),
  img: z.string().optional(),
  bloodType: z.string().min(1, { message: "Blood Type is required!" }),
  birthday: z.coerce.date({ message: "Birthday is required!" }),
  sex: z.enum(["MALE", "FEMALE"], { message: "Sex is required!" }),
  subjectOfferings: z.array(z.number()).optional(),
  subjects: z.array(z.string()).optional(), //subject Ids
  courseId: z.coerce.number().optional().or(z.literal("")),
});
export type TeacherSchema = z.infer<typeof teacherSchema>;

//Rules for students
export const studentSchema = z.object({
  id: z.string().optional(),
  username:z
  .string()
  .min(3, { message: "Username must be at least 3 characters long!" })
  .max(20, { message: "Username must be at most 20 characters long!" }),
  password:  z.string()
  .min(8, { message: "Password must be at least 8 characters long!" })
  .optional()
  .or(z.literal("")),
  name: z.string().min(1, "Name is required"),
  surname: z.string().min(1, "Surname is required"),
  email: z.string().email().optional().nullable(),
  phone: z.string().optional().nullable(),
  address: z.string().min(1, "Address is required"),
  bloodType: z.string().min(1, "Blood type is required"),
  sex: z.enum(["MALE", "FEMALE"]),
  birthday: z.coerce.date(),
  courseId: z.coerce.number().min(1, "Course is required"),
  currentSemesterId: z.coerce.number().min(1, "Semester is required"),
  parentId: z.string().optional().nullable(),
  img: z.string().optional().nullable(),
});
export type StudentSchema = z.infer<typeof studentSchema>;

//Rules for Exams
export const examSchema = z.object({
  id: z.coerce.number().optional(),
  title: z.string().min(1, { message: "Title name is required!" }),
  startTime:z.coerce.date({message:"Start time is required!"}),
  endTime:z.coerce.date({message:"End time is required!"}),
  lessonId:z.coerce.number({message:"Lesson is required!"}),
});
export type ExamSchema = z.infer<typeof examSchema>;

//Rules for Parents
export const parentSchema = z.object({
  id: z.string().optional(),
  username: z
    .string()
    .min(3, { message: "Username must be at least 3 characters long!" })
    .max(20, { message: "Username must be at most 20 characters long!" }),
  password: z
    .string()
    .min(8, { message: "Password must be at least 8 characters long!" })
    .optional()
    .or(z.literal("")),
  name: z.string().min(1, { message: "First name is required!" }),
  surname: z.string().min(1, { message: "Last name is required!" }),
  email: z
    .string()
    .email({ message: "Invalid email address!" })
    .optional()
    .or(z.literal("")),
  phone: z.string().optional(),
  address: z.string(),
  student: z.string().optional()
  .or(z.literal("")),
  
});

export type ParentSchema = z.infer<typeof parentSchema>;

// export const admissionSchema = z.object({
//   studentName: z.string().min(1, { message: "Student name is required!" }),
//   studentSurname: z.string().min(1, { message: "Student surname is required!" }),
//   email: z.string().email({ message: "Invalid email address!" }).optional(),
//   phone: z.string().min(10, { message: "Phone number is required!" }).optional(),
//   address: z.string().min(1, { message: "Address is required!" }),
//   birthday: z.string().min(1, { message: "Birthday is required!" }), // Will be converted to Date
//   bloodType: z.string().min(1, { message: "Blood type is required!" }),
//   sex: z.nativeEnum(UserSex),
//   courseId: z.number().min(1, { message: "Course ID is required!" }),

//   parentName: z.string().min(1, { message: "Parent name is required!" }),
//   parentPhone: z.string().min(10, { message: "Parent phone number is required!" }),
//   parentEmail: z.string().email({ message: "Invalid parent email!" }).optional(),
//   parentAddress: z.string().min(1, { message: "Parent address is required!" }),

//   paymentId: z.string().optional(), // Payment ID is optional at submission
// });
// export type AdmissionSchema = z.infer<typeof admissionSchema>;

export enum ParentVerificationStatus {
  PENDING = "PENDING",
  VERIFIED = "VERIFIED"
}

export enum PaymentVerificationStatus {
  PENDING = "PENDING",
  VERIFIED = "VERIFIED"
}

export enum AdmissionStatus {
  PENDING = "PENDING",
  PARENT_VERIFIED = "PARENT_VERIFIED",
  PAYMENT_VERIFIED = "PAYMENT_VERIFIED",
  COMPLETED = "COMPLETED",
  REJECTED = "REJECTED"
}

export enum PaymentStatus {
  PENDING = "PENDING",
  APPROVED = "APPROVED",
  REJECTED = "REJECTED"
}

// Schema for admission form validation
export const admissionSchema = z.object({
  id: z.coerce.number().optional(),
  studentName: z.string().min(1, { message: "Student name is required!" }),
  studentSurname: z.string().min(1, { message: "Student surname is required!" }),
  email: z.string().email({ message: "Invalid email format" }).optional().nullable(),
  phone: z.string().min(1, { message: "Phone number is required!" }),
  address: z.string().min(1, { message: "Address is required!" }),
  birthday: z.string().min(1, { message: "Birthday is required!" }),
  bloodType: z.string().min(1, { message: "Blood type is required!" }),
  sex: z.enum(["MALE", "FEMALE"], { message: "Sex is required!" }),
  courseId: z.coerce.number({ message: "Course is required!" }),
  parentName: z.string().min(1, { message: "Parent name is required!" }),
  parentPhone: z.string().min(1, { message: "Parent phone is required!" }),
  parentEmail: z.string().email({ message: "Parent email is required for verification!" }),
  parentAddress: z.string().min(1, { message: "Parent address is required!" }),
  status: z.enum(["PENDING", "PARENT_VERIFIED", "PAYMENT_VERIFIED", "COMPLETED", "REJECTED"]).optional(),
  parentVerificationStatus: z.enum(["PENDING", "VERIFIED"]).optional(),
});

export type AdmissionSchema = z.infer<typeof admissionSchema>;

// Add to existing schemas
export const subjectOfferingSchema = z.object({
  id: z.number().optional(),
  subjectId: z.coerce.number({
    required_error: "Subject is required",
    invalid_type_error: "Subject must be a number",
  }),
  semesterId: z.coerce.number({
    required_error: "Semester is required",
    invalid_type_error: "Semester must be a number",
  }),
  teacherId: z.string({
    required_error: "Teacher is required",
  }),
});

export type SubjectOfferingSchema = z.infer<typeof subjectOfferingSchema>;

export const attendanceSchema = z.object({
  id: z.number().optional(),
  date: z.coerce.date(),
  present: z.enum(["true", "false"]),
  studentId: z.string().min(1, "Student is required"),
  lessonId: z.coerce.number().min(1, "Lesson is required")
});