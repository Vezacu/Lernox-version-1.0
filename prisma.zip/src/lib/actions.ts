"use server";

import { revalidatePath } from "next/cache";
import {
  ClassSchema,
  ExamSchema,
  ParentSchema,
  StudentSchema,
  SubjectSchema,
  TeacherSchema,
  AdmissionSchema,
  SubjectOfferingSchema,
} from "./formValidationSchemas";
import prisma from "./prisma";
import { auth, clerkClient } from "@clerk/nextjs/server";
import { PaymentStatus, Prisma } from "@prisma/client";
import { error } from "console";

type CurrentState = { success: boolean; error: boolean; message?: string;};

export const createSubject = async (
  currentState: CurrentState,
  formData: FormData
) => {
  try {
    const data = {
      name: formData.get("name") as string,
    };

    await prisma.subject.create({ data });
    return { success: true, error: false };
  } catch (err) {
    console.error("Create subject error:", err);
    return { 
      success: false, 
      error: true, 
      message: err instanceof Error ? err.message : "Failed to create subject" 
    };
  }
};

export const updateSubject = async (
  currentState: CurrentState,
  formData: FormData
) => {
  try {
    const id = parseInt(formData.get("id") as string);
    const data = {
      name: formData.get("name") as string,
    };

    await prisma.subject.update({
      where: { id },
      data,
    });

   
    return { success: true, error: false };
  } catch (err) {
    console.error("Update subject error:", err);
    return { 
      success: false, 
      error: true, 
      message: err instanceof Error ? err.message : "Failed to update subject" 
    };
  }
};

export const deleteSubject = async (
  currentState: CurrentState,
  data: FormData
) => {
  const id = data.get("id") as string;
  try {
    await prisma.subject.delete({
      where: {
        id: parseInt(id),
      },
    });

    // revalidatePath("/list/class");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const createClass = async (
  currentState: CurrentState,
  data: ClassSchema
) => {
  try {
    await prisma.class.create({
      data,
    });

    // revalidatePath("/list/class");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const updateClass = async (
  currentState: CurrentState,
  data: ClassSchema
) => {
  try {
    await prisma.class.update({
      where: {
        id: data.id,
      },
      data,
    });

    // revalidatePath("/list/class");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const deleteClass = async (
  currentState: CurrentState,
  data: FormData
) => {
  const id = data.get("id") as string;
  try {
    await prisma.class.delete({
      where: {
        id: parseInt(id),
      },
    });

    // revalidatePath("/list/class");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};


export const createTeacher = async (
  currentState: CurrentState,
  data: TeacherSchema
) => {
  try {
    const client = await clerkClient();
    const user = await client.users.createUser({
      username: data.username,
      password: data.password,
      firstName: data.name,
      lastName: data.surname,
      publicMetadata: { role: "teacher" },
    });

    const teacher = await prisma.teacher.create({
      data: {
        id: user.id,
        username: data.username,
        name: data.name,
        surname: data.surname,
        email: data.email,
        phone: data.phone,
        address: data.address,
        img: data.img,
        bloodType: data.bloodType,
        sex: data.sex,
        birthday: data.birthday,
        // Connect to existing subject offerings if provided
        subjectOfferings: data.subjectOfferings?.length
          ? {
              connect: data.subjectOfferings.map((offeringId: number) => ({
                id: offeringId,
              })),
            }
          : undefined,
      },
    });

   
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const updateTeacher = async (
  currentState: CurrentState,
  data: TeacherSchema
) => {
  try {
    console.log("Updating teacher with data:", data);

    if (!data.id) {
      throw new Error("Teacher ID is required for update");
    }

    // Update Clerk user if email or password changed
    const client = await clerkClient();
    await client.users.updateUser(data.id, {
      username: data.username,
      firstName: data.name,
      lastName: data.surname,
      ...(data.password && { password: data.password })
    });

    // Update database record
    const teacher = await prisma.teacher.update({
      where: { id: data.id },
      data: {
        username: data.username,
        name: data.name,
        surname: data.surname,
        email: data.email,
        phone: data.phone,
        address: data.address,
        img: data.img,
        bloodType: data.bloodType,
        sex: data.sex,
        birthday: data.birthday,
        subjectOfferings: {
          set: data.subjectOfferings?.map(id => ({ id })) || []
        }
      },
    });

    console.log("Teacher updated successfully:", teacher);
    
    return { success: true, error: false };
  } catch (err) {
    console.error("Update teacher error:", err);
    return { 
      success: false, 
      error: true, 
      message: err instanceof Error ? err.message : "Failed to update teacher"
    };
  }
};

export const deleteTeacher = async (
  currentState: CurrentState,
  data: FormData
) => {
  const id = data.get("id") as string;
  try {
    // First delete related subject offerings
    await prisma.subjectOffering.deleteMany({
      where: { teacherId: id }
    });

    // Then delete the teacher
    await prisma.teacher.delete({
      where: { id }
    });

    // Finally delete Clerk user
    const client = await clerkClient();
    await client.users.deleteUser(id);

   
    return { success: true, error: false };
  } catch (err) {
    console.error("Delete teacher error:", err);
    return { 
      success: false, 
      error: true,
      message: "Cannot delete teacher with existing subject offerings. Delete related offerings first."
    };
  }
};

export const createStudent = async (
  currentState: CurrentState,
  data: StudentSchema
) => { 
  try {console.log("Creating student with data:", data); // Debug log
    const client = await clerkClient();
    const user = await client.users.createUser({
      username: data.username,
      password: data.password,
      firstName: data.name,
      lastName: data.surname,
      publicMetadata: { role: "student" },
    });
    console.log("Clerk user created:", user); // Debug log
    const student = await prisma.student.create({
      data: {
        id: user.id,
        username: data.username,
        name: data.name,
        surname: data.surname,
        email: data.email,
        phone: data.phone,
        address: data.address,
        img: data.img,
        bloodType: data.bloodType,
        sex: data.sex,
        birthday: data.birthday,
        courseId: data.courseId,
        currentSemesterId: data.currentSemesterId,
        parentId: data.parentId,
      },
    });
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const updateStudent = async (
  currentState: CurrentState,
  data: StudentSchema
) => {
  if (!data.id) {
    return { success: false, error: true, message: "Student ID is required" };
  }
  
  try {
    console.log("Updating student with data:", data); // Debug log
    
    // Update user in Clerk
    const client = await clerkClient();
    const user = await client.users.updateUser(data.id, {
      username: data.username,
      ...(data.password && data.password !== "" && { password: data.password }),
      firstName: data.name,
      lastName: data.surname,
    });
    
    console.log("Clerk user updated:", user.id); // Debug log
    
    // Update student in the database
    const student = await prisma.student.update({
      where: {
        id: data.id,
      },
      data: {
        username: data.username,
        name: data.name,
        surname: data.surname,
        email: data.email,
        phone: data.phone,
        address: data.address,
        img: data.img,
        bloodType: data.bloodType,
        sex: data.sex,
        birthday: data.birthday,
        courseId: Number(data.courseId),
        currentSemesterId: Number(data.currentSemesterId),
        parentId: data.parentId,
      },
    });
    
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};
export const deleteStudent = async (
  currentState: CurrentState,
  data: FormData
) => {
  const id = data.get("id") as string;
  try {
    const client = await clerkClient();
    const user = await client.users.deleteUser(id);

    await prisma.student.delete({
      where: {
        id: id,
      },
    });

    // revalidatePath("/list/students");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};
//EXAM...

export const createExam = async (
  currentState: CurrentState,
  data: ExamSchema
) => {
  const { userId, sessionClaims } = await auth();
  const role = (sessionClaims?.metadata as { role?: string })?.role;
  try {
    if (role === "teacher") {
      const teacherLesson = await prisma.lesson.findFirst({
        where: {
          teacherId: userId!,
          id: data.lessonId,
        },
      });

      if (!teacherLesson) {
        return { success: false, error: true };
      }
    }
    await prisma.exam.create({
      data: {
        title: data.title,
        startTime: data.startTime,
        endTime: data.endTime,
        lessonId: data.lessonId,
      },
    });

    // revalidatePath("/list/class");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const updateExam = async (
  currentState: CurrentState,
  data: ExamSchema
) => {
  const { userId, sessionClaims } = await auth();
  const role = (sessionClaims?.metadata as { role?: string })?.role;
  try {
    if (role === "teacher") {
      const teacherLesson = await prisma.lesson.findFirst({
        where: {
          teacherId: userId!,
          id: data.lessonId,
        },
      });

      if (!teacherLesson) {
        return { success: false, error: true };
      }
    }

    await prisma.exam.update({
      where: {
        id: data.id,
      },
      data: {
        title: data.title,
        startTime: data.startTime,
        endTime: data.endTime,
        lessonId: data.lessonId,
      },
    });

    // revalidatePath("/list/class");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const deleteExam = async (
  currentState: CurrentState,
  data: FormData
) => {
  const id = data.get("id") as string;

  // const { userId, sessionClaims } = await auth();
  // const role = (sessionClaims?.metadat as { role?: string })?.role;

  try {
    await prisma.exam.delete({
      where: {
        id: parseInt(id),
        // ...(role === "teacher" ? { lesson: { teacherId: userId! } } : {}),
      },
    });

    // revalidatePath("/list/class");
    return { success: true, error: false };
  } catch (err) {
    console.log(err);
    return { success: false, error: true };
  }
};

export const createParent = async (
  currentState: CurrentState,
  data: ParentSchema
) => {
  try {
    const clerk = await clerkClient();
    const users = await clerk.users.createUser({
      username: data.username,
      password: data.password,
      firstName: data.name,
      lastName: data.surname,
      publicMetadata: { role: "parent" },
    });

    await prisma.parent.create({
      data: {
        id: users.id,
        username: data.username,
        email: data.email || "",
        name: data.name || "",
        surname: data.surname || "",
        phone: data?.phone || "",
        address: data?.address || "",
      },
    });

    return { success: true, error: false };
  } catch (err) {
    console.error("Error creating parent:", err);
    return { success: false, error: true };
  }
};

export const updateParent = async (
  currentState: CurrentState,
  data: ParentSchema
) => {
  if (!data.id) {
    return { success: false, error: true };
  }
  try {
    const clerk = await clerkClient();
    const users = await clerk.users.updateUser(data.id, {
      username: data.username,
      ...(data.password !== "" && { password: data.password }),
      firstName: data.name,
      lastName: data.surname,
    });

    await prisma.parent.update({
      where: { id: String(data.id) },
      data: {
        ...(data.password !== "" && { password: data.password }),
        username: data.username,
        email: data.email || "",
        name: data.name || "",
        surname: data.surname || "",
        phone: data?.phone || "",
        address: data?.address || "",
      },
    });

    return { success: true, error: false };
  } catch (err) {
    console.log("Error updating parent:", err);
    return { success: false, error: true };
  }
};
export const deleteParent = async (
  currentState: CurrentState,
  data: FormData
) => {
  const id = data.get("id") as string;
  try {
    const clerk = await clerkClient();
    await clerk.users.deleteUser(id);
    await prisma.parent.delete({
      where: {
        id: id,
      },
    });

    return { success: true, error: false };
  } catch (err) {
    console.log("Error deleting parent:", err);
    return { success: false, error: true };
  }
};

export const createResult = async (
  data: { studentId: string; subjectId: number; marks: number; grade: string }[]
) => {
  console.log("Function createResult called with data:", data);

  try {
    if (!data || data.length === 0) {
      throw new Error("No data provided for insertion.");
    }

    // Validate if student exists
    const studentExists = await prisma.student.findUnique({
      where: { id: data[0].studentId },
    });

    if (!studentExists) {
      throw new Error(`Student with ID '${data[0].studentId}' not found.`);
    }

    console.log("Student validation passed.");

    // Validate if subjects exist
    const subjectIds = data.map((entry) => entry.subjectId);
    const subjects = await prisma.subject.findMany({
      where: { id: { in: subjectIds } },
    });

    if (subjects.length !== subjectIds.length) {
      throw new Error("One or more subject IDs are invalid.");
    }

    console.log("Subject validation passed.");

    // Insert data using Prisma transaction
    const results = await prisma.$transaction(
      data.map((result) =>
        prisma.result.create({
          data: {
            studentId: result.studentId,
            subjectId: result.subjectId, // Keep as number since schema expects number
            marks: result.marks,
            grade: result.grade,
          },
        })
      )
    );

    console.log("Inserted results:", results);
    return { success: true, results };
  } catch (error) {
    console.error("Error creating results:", error);
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      console.error("Prisma Client Error:", error);
    }
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
};

// Update an existing result
export const updateResult = async (id: number, data: ResultSchema) => {
  try {
    console.log("Updating result with data:", data);
    const result = await prisma.result.update({
      where: { id: id.toString() }, // Ensure id is a string if your schema expects it
      data: {
        studentId: data.studentId,
        subjectId: data.subjects[0].subjectId, // Assuming you want to update the first subject
        marks: data.subjects[0].marks,
      },
    });
    return { success: true, result };
  } catch (error) {
    console.error("Error updating result:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
};

// Delete a result
export const deleteResult = async (
  prevState: { success: boolean; error: boolean },
  formData: FormData
) => {
  try {
    const id = formData.get("id") as string;

    if (!id) {
      return { success: false, error: true };
    }

    await prisma.result.delete({
      where: {
        id: id, // Use the ID as a string directly
      },
    });

    return { success: true, error: false };
  } catch (error) {
    console.error("Error deleting result:", error);
    return { success: false, error: true };
  }
};

// export const createAttendance = async (data: AttendanceSchema) => {
//   try {
//     const attendance = await prisma.attendance.create({
//       data: {
//         className: data.className,
//         date: new Date(data.date), // Ensure valid Date object
//         day: data.day,
//         present: data.present,
//         total: data.total,
//       },
//     });
//     return { success: true, attendance };
//   } catch (error) {
//     console.error("Error creating attendance:", error);
//     return {
//       success: false,
//       error: error instanceof Error ? error.message : "Unknown error",
//     };
//   }
// };

// export const updateAttendance = async (id: number, data: AttendanceSchema) => {
//   try {
//     const attendance = await prisma.attendance.update({
//       where: { id },
//       data: {
//         className: data.className,
//         date: new Date(data.date),
//         day: data.day,
//         present: data.present,
//         total: data.total,
//       },
//     });
//     console.log("Updated Attendance:", attendance);
//     return { success: true, attendance };
//   } catch (error) {
//     console.error("Error updating attendance:", error);
//     return {
//       success: false,
//       error: error instanceof Error ? error.message : "Unknown error",
//     };
//   }
// };

// export const deleteAttendance = async (
//   prevState: { success: boolean; error: boolean },
//   formData: FormData
// ) => {
//   try {
//     const id = formData.get("id") as string;

//     if (!id) {
//       return { success: false, error: true };
//     }

//     await prisma.attendance.delete({
//       where: {
//         id: Number(id), // Convert ID to a number
//       },
//     });

//     return { success: true, error: false };
//   } catch (err) {
//     console.error("Error deleting attendance:", err);
//     return { success: false, error: true };
//   }
// };

// export async function createAdmission(prevState: any, formData: any) {
//   try {
//     // Create a new admission form record in the database
//     const newAdmission = await prisma.admissionForm.create({
//       data: {
//         studentName: formData.studentName,
//         studentSurname: formData.studentSurname,
//         email: formData.email || null,
//         phone: formData.phone || null,
//         address: formData.address,
//         birthday: new Date(formData.birthday),
//         bloodType: formData.bloodType,
//         sex: formData.sex,
//         courseId: parseInt(formData.courseId),
//         img: formData.img || null,
//         parentName: formData.parentName,
//         parentPhone: formData.parentPhone,
//         parentEmail: formData.parentEmail || null,
//         parentAddress: formData.parentAddress,
//         status: "PENDING", // Default status
//       },
//     });

//     // Revalidate the admission path to show updated data
//     revalidatePath("/admission");
    
//     return { success: true, error: false, data: newAdmission };
//   } catch (error) {
//     console.error("Error creating admission form:", error);
//     return { success: false, error: true, message: "Failed to create admission form" };
//   }
// }

// export async function getCourses() {
//   try {
//     const courses = await prisma.course.findMany();
//     return courses;
//   } catch (error) {
//     console.error("Error fetching courses:", error);
//     return [];
//   }
// };
export const createAdmission = async (
  prevState: any,
  data: any
) => {
  try {
    // Check if the course exists
    const course = await prisma.course.findUnique({
      where: { id: parseInt(data.courseId) },
    });

    if (!course) {
      return { success: false, error: true, message: "Course not found" };
    }

    // Create the admission record in the database
    const newAdmission = await prisma.admissionForm.create({
      data: {
        studentName: data.studentName,
        studentSurname: data.studentSurname,
        email: data.email || null,
        phone: data.phone || null,
        address: data.address,
        birthday: new Date(data.birthday),
        bloodType: data.bloodType,
        sex: data.sex,
        courseId: parseInt(data.courseId),
        img: data.img || null,
        parentName: data.parentName,
        parentPhone: data.parentPhone,
        parentEmail: data.parentEmail || null,
        parentAddress: data.parentAddress,
        status: "PENDING", // Default status
      },
    });

    // Revalidate the admission path to show updated data
    revalidatePath("/admission");

    return { success: true, error: false, data: newAdmission };
  } catch (error) {
    console.error("Error creating admission form:", error);
    return { success: false, error: true, message: "Failed to create admission form" };
  }
};


// Add to existing actions

export const createSubjectOffering = async (
  currentState: CurrentState,
  data: SubjectOfferingSchema
) => {
  try {
    console.log("Creating subject offering with data:", data); // Debug log
    
    // Validate inputs
    if (!data.subjectId || !data.semesterId || !data.teacherId) {
      console.error("Missing required fields:", { data });
      return { 
        success: false, 
        error: true, 
        message: "All fields are required" 
      };
    }
    
    // Create subject offering
    const newSubjectOffering = await prisma.subjectOffering.create({
      data: {
        subjectId: data.subjectId,
        semesterId: data.semesterId,
        teacherId: data.teacherId,
      },
      include: {
        subject: true,
        semester: {
          include: {
            course: true,
          },
        },
        teacher: true,
      },
    });
    
    console.log("Subject offering created:", newSubjectOffering.id); // Debug log
    return { success: true, error: false };
  } catch (err) {
    console.error("Error creating subject offering:", err);
    return { success: false, error: true, message: "Failed to create subject offering" };
  }
};

export const updateSubjectOffering = async (
  currentState: CurrentState,
  data: SubjectOfferingSchema
) => {
  try {
    console.log("Updating subject offering with data:", data); // Debug log
    
    // Validate inputs
    if (!data.id || !data.subjectId || !data.semesterId || !data.teacherId) {
      console.error("Missing required fields:", { data });
      return { 
        success: false, 
        error: true, 
        message: "All fields are required" 
      };
    }
    
    // Update subject offering
    const updatedSubjectOffering = await prisma.subjectOffering.update({
      where: { id: data.id },
      data: {
        subjectId: data.subjectId,
        semesterId: data.semesterId,
        teacherId: data.teacherId,
      },
      include: {
        subject: true,
        semester: {
          include: {
            course: true,
          },
        },
        teacher: true,
      },
    });
    
    console.log("Subject offering updated:", updatedSubjectOffering.id); // Debug log
    return { success: true, error: false };
  } catch (err) {
    console.error("Error updating subject offering:", err);
    return { success: false, error: true, message: "Failed to update subject offering" };
  }
};

export const deleteSubjectOffering = async (
  currentState: CurrentState,
  data: FormData
) => {
  const id = data.get("id") as string;
  try {
    console.log("Deleting subject offering with id:", id); // Debug log
    
    // Validate input
    if (!id) {
      console.error("Missing ID for delete operation");
      return { 
        success: false, 
        error: true, 
        message: "Subject offering ID is required" 
      };
    }
    
    // Delete subject offering
    const deletedSubjectOffering = await prisma.subjectOffering.delete({
      where: { id: parseInt(id) },
    });
    
    console.log("Subject offering deleted:", id); // Debug log
    return { success: true, error: false };
  } catch (err) {
    console.error("Error deleting subject offering:", err);
    return { success: false, error: true, message: "Failed to delete subject offering" };
  }
};

export const saveBulkAttendance = async (attendances: {
  studentId: string;
  lessonId: string;
  date: Date;
  present: boolean;
}[]) => {
  try {
    await prisma.$transaction(
      attendances.map(attendance =>
        prisma.attendance.upsert({
          where: {
            studentId_lessonId_date: {
              studentId: attendance.studentId,
              lessonId: Number(attendance.lessonId),
              date: attendance.date
            }
          },
          update: { present: attendance.present },
          create: {
            ...attendance,
            lessonId: Number(attendance.lessonId),
            date: attendance.date
          }
        })
      )
    );
    return { success: true, error: false };
  } catch (error) {
    console.error('Bulk attendance save error:', error);
    return { success: false, error: true };
  }
};